﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Kaizen.Assessment.UnitTest
{
    [TestClass]
    public class AssessmentA
    {
        [TestMethod]
        public void HasBase()
        {
            Assert.AreNotSame(typeof(Object), typeof(Human).BaseType);
        }

        [TestMethod]
        public void HasAbstract()
        {
            Assert.IsTrue(typeof(Human).BaseType.IsAbstract);
        }

        [TestMethod]
        public void HasToString()
        {
            Assert.AreSame(typeof(Human).GetMethod("ToString").DeclaringType, typeof(Human));
        }

        [TestMethod]
        public void HasBaseMethod()
        {
            Assert.AreNotSame(typeof(Object), typeof(Human).BaseType);

            Assert.AreSame(typeof(Human).BaseType.GetMethod("GetDetails").DeclaringType, typeof(Human).BaseType);
        }

        [TestMethod]
        public void HasBaseProps()
        {
            var properties = typeof (Human).BaseType.GetProperties().ToList();

            Assert.IsTrue(properties.Count > 0);

            Assert.IsTrue(properties.FirstOrDefault(x => x.Name.Equals("Name")) != null);
            Assert.IsTrue(properties.FirstOrDefault(x => x.Name.Equals("Age")) != null);
        }

        [TestMethod]
        public void ZBonus1()
        {
            var baseType = typeof (Human).BaseType;
            Assert.IsTrue(baseType != null);
            {
                var interfaces = baseType.GetInterfaces();
                Assert.IsTrue(interfaces != null && interfaces.Any());
            }
        }
    }
}
